package ru.startandroid.develop.chatting.Adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ru.startandroid.develop.chatting.MessageActivity;
import ru.startandroid.develop.chatting.R;
import ru.startandroid.develop.chatting.model.Chat;
import ru.startandroid.develop.chatting.model.User;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

    public static final int MSG_TYPE_LEFT = 0;
    public static final int MSG_TYPE_RIGHT = 1;
    private final Context mContext;
    private List<Chat> mChat;
    private final String imageurl;
    private final DatabaseReference messagesRef;
    private final String currentUserId;

    public interface OnItemClickListener {
        void onItemClick(Chat chat);
    }
    public MessageAdapter(Context mContext, List<Chat> mChat, String imageurl) {
        this.mChat = mChat != null ? mChat : new ArrayList<>();
        this.mContext = mContext;
        this.imageurl = imageurl;
        this.currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        this.messagesRef = FirebaseDatabase.getInstance().getReference("Chats");
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(
                viewType == MSG_TYPE_RIGHT ? R.layout.chat_item_right : R.layout.chat_item_left,
                parent, false);
        return new ViewHolder(view, viewType);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Chat chat = mChat.get(position);
        boolean isCurrentUser = chat.getSender() != null && chat.getSender().equals(currentUserId);

        // Set message text
        holder.show_message.setText(chat.getMessage());

        // Set profile image
        if (imageurl.equals("default")) {
            holder.profile_image.setImageResource(R.mipmap.ic_launcher);
        } else {
            Glide.with(mContext).load(imageurl).into(holder.profile_image);
        }

        // Set seen/delivered status
        if (position == mChat.size()-1) {
            holder.txt_seen.setText(chat.isIsseen() ? "Seen" : "Delivered");
            holder.txt_seen.setVisibility(View.VISIBLE);
        } else {
            holder.txt_seen.setVisibility(View.GONE);
        }


//        if (chat.getReaction() != null && !chat.getReaction().isEmpty()) {
//            holder.reaction_text.setText(chat.getReaction());
//            holder.reaction_text.setVisibility(View.VISIBLE);
//
//            RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) holder.reaction_text.getLayoutParams();
//            params.addRule(RelativeLayout.ALIGN_BOTTOM, R.id.show_message);
//            params.removeRule(RelativeLayout.LEFT_OF);
//            params.removeRule(RelativeLayout.RIGHT_OF);
//
//            if (isCurrentUser) {
//                params.addRule(RelativeLayout.LEFT_OF, R.id.show_message);
//                params.rightMargin = 0;
//                params.leftMargin = 4;
//            } else {
//                params.addRule(RelativeLayout.RIGHT_OF, R.id.show_message);
//                params.leftMargin = 0;
//                params.rightMargin = 4;
//            }
//
//            holder.reaction_text.setLayoutParams(params);
//        } else {
//            holder.reaction_text.setVisibility(View.GONE);
//        }

        if (chat.getReaction() != null && !chat.getReaction().isEmpty()) {
            holder.reaction_text.setText(chat.getReaction());
            holder.reaction_text.setVisibility(View.VISIBLE);

            RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) holder.reaction_text.getLayoutParams();
            params.addRule(RelativeLayout.ALIGN_BOTTOM, R.id.show_message);
            params.removeRule(RelativeLayout.LEFT_OF);
            params.removeRule(RelativeLayout.RIGHT_OF);

            if (isCurrentUser) {
                params.addRule(RelativeLayout.LEFT_OF, R.id.show_message);
                params.rightMargin = 0;
                params.leftMargin = 4;
            } else {
                params.addRule(RelativeLayout.RIGHT_OF, R.id.show_message);
                params.leftMargin = 0;
                params.rightMargin = 4;
            }

            holder.reaction_text.setLayoutParams(params);
        } else {
            holder.reaction_text.setVisibility(View.GONE);
        }


        // Set long click listener
        holder.itemView.setOnLongClickListener(v -> {
            showMessageOptions(chat, position, isCurrentUser, v);
            return true;
        });
    }


    private void showMessageOptions(Chat chat, int position, boolean isCurrentUser, View anchorView) {
        PopupMenu popupMenu = new PopupMenu(mContext, anchorView);
        popupMenu.inflate(R.menu.message_options_menu);

        Menu menu = popupMenu.getMenu();
        menu.findItem(R.id.unsend).setVisible(isCurrentUser);
        menu.findItem(R.id.edit).setVisible(isCurrentUser);

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.unsend) {
                unsendMessage(chat, position);
                return true;
            } else if (itemId == R.id.edit) {
                editMessage(chat, position);
                return true;
            } else if (itemId == R.id.react) {
                showReactionOptions(chat, anchorView);
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

//    private void unsendMessage(Chat chat, int position) {
//        String messageId = chat.getMessageId();
//        if (messageId == null) {
//            Toast.makeText(mContext, "Invalid message", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        messagesRef.child(messageId).removeValue()
//                .addOnCompleteListener(task -> {
//                    if (task.isSuccessful()) {
//                        mChat.remove(position);
//                        notifyItemRemoved(position);
//                        notifyItemRangeChanged(position, mChat.size());
//                    } else {
//                        Toast.makeText(mContext, "Failed to unsend message", Toast.LENGTH_SHORT).show();
//                    }
//                });
//    }

    private void unsendMessage(Chat chat, int position) {
        String messageId = chat.getMessageId();
        if (messageId == null) {
            Toast.makeText(mContext, "Invalid message", Toast.LENGTH_SHORT).show();
            return;
        }

        messagesRef.child(messageId).removeValue()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Instead of relying on position, find the message safely by ID:
                        int indexToRemove = -1;
                        for (int i = 0; i < mChat.size(); i++) {
                            String id = mChat.get(i).getMessageId();
                            if (messageId.equals(id)) {  // safe equals check
                                indexToRemove = i;
                                break;
                            }
                        }
                        if (indexToRemove != -1) {
                            mChat.remove(indexToRemove);
                            notifyItemRemoved(indexToRemove);
                            notifyItemRangeChanged(indexToRemove, mChat.size());
                        } else {
                            Toast.makeText(mContext, "Message not found in list", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(mContext, "Failed to unsend message", Toast.LENGTH_SHORT).show();
                    }
                });
    }



    private void updateMessage(Chat chat, String newMessage, int position) {
        String messageId = chat.getMessageId();
        if (messageId == null) {
            Toast.makeText(mContext, "Invalid message", Toast.LENGTH_SHORT).show();
            return;
        }

        messagesRef.child(messageId).child("message").setValue(newMessage)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        mChat.get(position).setMessage(newMessage);
                        notifyItemChanged(position);
                    } else {
                        Toast.makeText(mContext, "Failed to edit message", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void editMessage(Chat chat, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle("Edit Message");

        final EditText input = new EditText(mContext);
        input.setText(chat.getMessage());
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newMessage = input.getText().toString().trim();
            if (!newMessage.isEmpty()) {
                updateMessage(chat, newMessage, position);
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

//    private void showReactionOptions(Chat chat, View anchorView) {
//        PopupMenu reactionMenu = new PopupMenu(mContext, anchorView);
//        reactionMenu.inflate(R.menu.reaction_menu);
//
//        reactionMenu.setOnMenuItemClickListener(item -> {
//            int itemId = item.getItemId();
//            String reaction;
//
//            if (itemId == R.id.react_like) {
//                reaction = "👍";
//            } else if (itemId == R.id.react_love) {
//                reaction = "❤️";
//            } else if (itemId == R.id.react_laugh) {
//                reaction = "😂";
//            } else if (itemId == R.id.react_sad) {
//                reaction = "😢";
//            } else if (itemId == R.id.react_angry) {
//                reaction = "😠";
//            } else if (itemId == R.id.react_remove) {
//                reaction = "";
//            } else {
//                reaction = "";
//            }
//
//            messagesRef.child(chat.getMessageId()).child("reaction").setValue(reaction)
//                    .addOnCompleteListener(task -> {
//                        if (task.isSuccessful()) {
//                            chat.setReaction(reaction);  // Update local reaction
//                            notifyItemChanged(mChat.indexOf(chat));  // Refresh message item
//                        }
//                    });
//            return true;
//        });
//
//        reactionMenu.show();
//    }

    private void showReactionOptions(Chat chat, View anchorView) {
        PopupMenu reactionMenu = new PopupMenu(mContext, anchorView);
        reactionMenu.inflate(R.menu.reaction_menu);

        reactionMenu.setOnMenuItemClickListener(item -> {
            String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            String senderId = chat.getSender();
            boolean isSender = currentUserId.equals(senderId);

            String selectedReaction = "";
            int itemId = item.getItemId();

            if (itemId == R.id.react_like) selectedReaction = "👍";
            else if (itemId == R.id.react_love) selectedReaction = "❤️";
            else if (itemId == R.id.react_laugh) selectedReaction = "😂";
            else if (itemId == R.id.react_sad) selectedReaction = "😢";
            else if (itemId == R.id.react_angry) selectedReaction = "😠";
            else if (itemId == R.id.react_remove) selectedReaction = " ";  // Use space for “no reaction”

            String finalSelectedReaction = selectedReaction;

            messagesRef.child(chat.getMessageId()).child("reaction")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String currentReaction = snapshot.getValue(String.class);

                            String senderReact = " ";   // space = empty slot
                            String receiverReact = " ";

                            if (currentReaction != null) {
                                senderReact = getEmojiAt(currentReaction, 0);
                                receiverReact = getEmojiAt(currentReaction, 1);
                            }

                            // Update the correct slot based on who is reacting
                            if (isSender) {
                                senderReact = finalSelectedReaction.isEmpty() ? " " : finalSelectedReaction;
                            } else {
                                receiverReact = finalSelectedReaction.isEmpty() ? " " : finalSelectedReaction;
                            }

                            // Build updated reaction string with exactly 2 chars
                            String updatedReaction = senderReact + receiverReact;

                            // Save updated reaction string back to Firebase
                            messagesRef.child(chat.getMessageId()).child("reaction").setValue(updatedReaction)
                                    .addOnCompleteListener(task -> {
                                        if (task.isSuccessful()) {
                                            chat.setReaction(updatedReaction);
                                            notifyItemChanged(mChat.indexOf(chat));
                                        }
                                    });
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Log.e("Reaction", "Error: " + error.getMessage());
                        }
                    });

            return true;
        });

        reactionMenu.show();
    }

    // This method extracts the Nth emoji from the concatenated emoji string
    private String getEmojiAt(String reactionStr, int position) {
        // Emojis can be multiple chars, so use an iterator over code points
        int count = 0;
        int index = 0;
        while (index < reactionStr.length()) {
            int codePoint = reactionStr.codePointAt(index);
            int charCount = Character.charCount(codePoint);

            if (count == position) {
                return reactionStr.substring(index, index + charCount);
            }
            index += charCount;
            count++;
        }
        return " ";  // return space if no emoji found at position
    }


//    private void showReactionOptions(Chat chat, View anchorView) {
//        PopupMenu reactionMenu = new PopupMenu(mContext, anchorView);
//        reactionMenu.inflate(R.menu.reaction_menu);
//
//        reactionMenu.setOnMenuItemClickListener(item -> {
//            int itemId = item.getItemId();
//            String reaction;
//
//            if (itemId == R.id.react_like) {
//                reaction = "👍";
//            } else if (itemId == R.id.react_love) {
//                reaction = "❤️";
//            } else if (itemId == R.id.react_laugh) {
//                reaction = "😂";
//            } else if (itemId == R.id.react_sad) {
//                reaction = "😢";
//            } else if (itemId == R.id.react_angry) {
//                reaction = "😠";
//            } else if (itemId == R.id.react_remove) {
//                reaction = "";
//            } else {
//                reaction = "";
//            }
//
//            // Use currentUserId as key for this user's reaction under the message's reaction node
//            String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
//
//            DatabaseReference reactionRef = messagesRef.child(chat.getMessageId()).child("reaction").child(currentUserId);
//
//            // If reaction is empty string, remove this user's reaction
//            if (reaction.isEmpty()) {
//                reactionRef.removeValue().addOnCompleteListener(task -> {
//                    if (task.isSuccessful()) {
//                        // Remove from local chat reaction map (you'll need to add one)
//                        // For simplicity, you might reload chat or handle locally
//                        notifyItemChanged(mChat.indexOf(chat));
//                    }
//                });
//            } else {
//                reactionRef.setValue(reaction).addOnCompleteListener(task -> {
//                    if (task.isSuccessful()) {
//                        // Update local chat reaction map, if you keep one in Chat class
//                        notifyItemChanged(mChat.indexOf(chat));
//                    }
//                });
//            }
//            return true;
//        });
//
//        reactionMenu.show();
//    }


    @Override
    public int getItemCount() {
        return mChat != null ? mChat.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView show_message;
        public ImageView profile_image;
        public TextView txt_seen;
        public TextView reaction_text;

        public ViewHolder(View itemView, int viewType) {
            super(itemView);
            show_message = itemView.findViewById(R.id.show_message);
            profile_image = itemView.findViewById(R.id.profile_image);
            txt_seen = itemView.findViewById(R.id.txt_seen);
            reaction_text = itemView.findViewById(R.id.reaction_text);

            // Make sure reaction_text exists in your layout
            if (reaction_text == null) {
                throw new RuntimeException("reaction_text TextView not found in layout");
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        Chat chat = mChat.get(position);
        if (chat.getSender() != null && chat.getSender().equals(currentUserId)) {
            return MSG_TYPE_RIGHT;
        } else {
            return MSG_TYPE_LEFT;
        }
    }
}

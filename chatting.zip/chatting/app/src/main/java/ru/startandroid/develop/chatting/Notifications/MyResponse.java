package ru.startandroid.develop.chatting.Notifications;

public class MyResponse {
    public  int success;
}

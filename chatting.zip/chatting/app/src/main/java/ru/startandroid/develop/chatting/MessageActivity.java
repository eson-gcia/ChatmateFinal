package ru.startandroid.develop.chatting;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import ru.startandroid.develop.chatting.Adapter.MessageAdapter;
import ru.startandroid.develop.chatting.Fragments.APiService;
import ru.startandroid.develop.chatting.Notifications.*;
import ru.startandroid.develop.chatting.model.Chat;
import ru.startandroid.develop.chatting.model.User;

public class MessageActivity extends AppCompatActivity {

    private String userid;
    private ShapeableImageView profile_image;
    private TextView username;

    FirebaseUser fuser;
    DatabaseReference reference;

    ImageButton btn_send;
    EditText text_send;

    MessageAdapter messageAdapter;
    List<Chat> mChat;
    RecyclerView recyclerView;
    Intent intent;
    ValueEventListener seenListener;

    APiService aPiService;
    boolean notify = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        profile_image = findViewById(R.id.profile_image);
        username = findViewById(R.id.username);
        btn_send = findViewById(R.id.btn_send);
        text_send = findViewById(R.id.text_send);

        intent = getIntent();
        userid = intent.getStringExtra("userid");
        fuser = FirebaseAuth.getInstance().getCurrentUser();

        btn_send.setOnClickListener(v -> {
            notify = true;
            String msg = text_send.getText().toString();
            if (!msg.isEmpty()) {
                sendMessage(fuser.getUid(), userid, msg);
                text_send.setText("");
            } else {
                Toast.makeText(MessageActivity.this, "You can't send empty message", Toast.LENGTH_SHORT).show();
            }
        });

        reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue(User.class);
                if (user != null) {
                    username.setText(user.getUsername());
                    Glide.with(getApplicationContext()).load(user.getImageURL()).into(profile_image);
                    readMessages(fuser.getUid(), userid, user.getImageURL());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

        seenMessage(userid);
    }

    private void sendMessage(String sender, final String receiver, String message) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        String messageId = reference.child("Chats").push().getKey();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("messageId", messageId);
        hashMap.put("sender", sender);
        hashMap.put("receiver", receiver);
        hashMap.put("message", message);
        hashMap.put("isseen", false);
        hashMap.put("reaction", "");

        reference.child("Chats").child(messageId).setValue(hashMap);

        DatabaseReference chatRef = FirebaseDatabase.getInstance().getReference("Chatlist")
                .child(fuser.getUid()).child(userid);

        chatRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    chatRef.child("id").setValue(userid);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

//        sendNotification(receiver, message);
    }

//    private void sendNotification(String receiver, final String message) {
//        DatabaseReference tokens = FirebaseDatabase.getInstance().getReference("Tokens");
//        tokens.orderByKey().equalTo(receiver).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
//                    Token token = snapshot1.getValue(Token.class);
//                    Data data = new Data(fuser.getUid(), R.mipmap.ic_launcher, "New message: " + message, "New Message", userid);
//                    Sender sender = new Sender(data, token.getToken());
//                    aPiService.sendNotification(sender).enqueue(new Callback<MyResponse>() {
//                        @Override
//                        public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
//                            if (response.code() == 200 && response.body() != null && response.body().success != 1) {
//                                Toast.makeText(MessageActivity.this, "Failed to send notification", Toast.LENGTH_SHORT).show();
//                            }
//                        }
//
//                        @Override
//                        public void onFailure(Call<MyResponse> call, Throwable t) {}
//                    });
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {}
//        });
//    }

    private void readMessages(final String myid, final String userid, final String imageurl) {
        mChat = new ArrayList<>();
        reference = FirebaseDatabase.getInstance().getReference("Chats");

        // Initialize adapter once outside the listener
        messageAdapter = new MessageAdapter(MessageActivity.this, mChat, imageurl);
        recyclerView.setAdapter(messageAdapter);

        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, String previousChildName) {
                Chat chat = snapshot.getValue(Chat.class);
                if (chat != null &&
                        chat.getSender() != null &&
                        chat.getReceiver() != null &&
                        ((chat.getReceiver().equals(myid) && chat.getSender().equals(userid)) ||
                                (chat.getReceiver().equals(userid) && chat.getSender().equals(myid)))) {

                    // Check for duplicates
                    boolean exists = false;
                    for (Chat c : mChat) {
                        if (c.getMessageId() != null && c.getMessageId().equals(chat.getMessageId())) {
                            exists = true;
                            break;
                        }
                    }

                    if (!exists) {
                        mChat.add(chat);
                        messageAdapter.notifyItemInserted(mChat.size() - 1);
                        recyclerView.scrollToPosition(mChat.size() - 1);
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) {
                Chat updatedChat = snapshot.getValue(Chat.class);
                if (updatedChat != null) {
                    for (int i = 0; i < mChat.size(); i++) {
                        if (mChat.get(i).getMessageId() != null &&
                                mChat.get(i).getMessageId().equals(updatedChat.getMessageId())) {
                            mChat.set(i, updatedChat);
                            messageAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                Chat removedChat = snapshot.getValue(Chat.class);
                if (removedChat != null) {
                    for (int i = 0; i < mChat.size(); i++) {
                        if (mChat.get(i).getMessageId() != null &&
                                mChat.get(i).getMessageId().equals(removedChat.getMessageId())) {
                            mChat.remove(i);
                            messageAdapter.notifyItemRemoved(i);
                            break;
                        }
                    }
                }
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) {
                // Not needed for chat implementation
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MessageActivity.this, "Failed to load messages: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showMessageOptions(Chat chat) {
        // Only allow options for messages sent by current user
        if (chat.getSender().equals(fuser.getUid())) {
            String[] options = {"Edit", "Delete", "React"};
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Select an option")
                    .setItems(options, (dialog, which) -> {
                        switch (which) {
                            case 0: // Edit
                                showEditDialog(chat);
                                break;
                            case 1: // Delete
                                deleteMessage(chat.getMessageId());
                                break;
                            case 2: // React
                                showReactionOptions(chat);
                                break;
                        }
                    }).show();
        } else {
            // For messages received, only show react option
            showReactionOptions(chat);
        }
    }

    private void showEditDialog(Chat chat) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Message");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(chat.getMessage());
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newMessage = input.getText().toString();
            editMessage(chat.getMessageId(), newMessage);
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void showReactionOptions(Chat chat) {
        String[] emojis = {"👍", "❤️", "😂", "😢", "😡", "❌"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("React with an emoji")
                .setItems(emojis, (dialog, which) -> {
                    String selectedReaction = emojis[which];
                    reactToMessage(chat.getMessageId(), selectedReaction);
                }).show();
    }

    public void editMessage(String messageId, String newMessage) {
        FirebaseDatabase.getInstance().getReference("Chats").child(messageId).child("message").setValue(newMessage);
    }

    public void deleteMessage(String messageId) {
        if (messageId == null || messageId.isEmpty()) return;

        FirebaseDatabase.getInstance().getReference("Chats")
                .child(messageId)
                .removeValue()
                .addOnSuccessListener(aVoid -> {
                    // Success handling
                    Toast.makeText(MessageActivity.this, "Message deleted", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    // Error handling
                    Toast.makeText(MessageActivity.this, "Failed to delete message", Toast.LENGTH_SHORT).show();
                    Log.e("MessageActivity", "Delete failed", e);
                });
    }

    public void reactToMessage(String messageId, String reaction) {
        FirebaseDatabase.getInstance().getReference("Chats").child(messageId).child("reaction").setValue(reaction);
    }

    private void seenMessage(final String userid) {
        // Check if userid is valid
        if (userid == null || fuser == null || fuser.getUid() == null) {
            return;
        }

        reference = FirebaseDatabase.getInstance().getReference("Chats");
        seenListener = reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    Chat chat = snapshot1.getValue(Chat.class);
                    // Add comprehensive null checks
                    if (chat != null &&
                            chat.getReceiver() != null &&
                            chat.getSender() != null &&
                            chat.getReceiver().equals(fuser.getUid()) &&
                            chat.getSender().equals(userid)) {

                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("isseen", true);
                        snapshot1.getRef().updateChildren(hashMap);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Add proper error handling
                Log.e("MessageActivity", "Error updating seen status: " + error.getMessage());
                Toast.makeText(MessageActivity.this, "Error updating message status", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void status(String status) {
        reference = FirebaseDatabase.getInstance().getReference("Users").child(fuser.getUid());
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("status", status);
        reference.updateChildren(hashMap);
    }

    @Override
    protected void onResume() {
        super.onResume();
        status("Online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        reference.removeEventListener(seenListener);
        status("Offline");
    }
}
